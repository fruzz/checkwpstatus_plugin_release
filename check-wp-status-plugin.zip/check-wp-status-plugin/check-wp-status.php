<?php
/*
Plugin Name: Check WP status
Plugin URI: https://Gloo.pl
Description: Ten plugin zwraca status WordPressa w endpoincie do którego potrzebny jest token uwierzytelniający zapytanie
Version: 1.0
Author: Gloo Software house
Author URI: https://Gloo.pl
Requires PHP: 8.5
*/

require_once plugin_dir_path(__FILE__) . 'includes/check-update.php';
require_once plugin_dir_path(__FILE__) . 'includes/helpers.php';
require_once plugin_dir_path(__FILE__) . 'includes/api-endpoint.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/rewrite-rules.php';