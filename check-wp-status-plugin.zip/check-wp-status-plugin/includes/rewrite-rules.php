<?php
function register_check_wp_status_endpoint() {
    add_rewrite_rule('^checkwpstatus/?$', 'index.php?checkwpstatus=1', 'top');
    add_rewrite_tag('%checkwpstatus%', '1');
}

function add_check_wp_status_query_var($vars) {
    $vars[] = 'checkwpstatus';
    return $vars;
}

function check_wp_status_template_redirect() {
    $checkwpstatus = get_query_var('checkwpstatus');
    if ($checkwpstatus) {
        check_wp_status_api_endpoint();
        exit;
    }
}

add_action('init', 'register_check_wp_status_endpoint');
add_filter('query_vars', 'add_check_wp_status_query_var');
add_action('template_redirect', 'check_wp_status_template_redirect');