<?php
function check_wp_status_save_token() {
    if (isset($_POST['check_wp_status_token'])) {
        $token = $_POST['check_wp_status_token'];
        update_option('check_wp_status_token', $token);
    }
}

function check_wp_status_generate_token() {
    $generated_token = generate_random_token(128);
    update_option('check_wp_status_token', $generated_token);
}

function check_wp_status_settings_menu() {
    add_options_page('Check WP status Settings', 'Check WP status', 'manage_options', 'check-wp-status-settings', 'check_wp_status_settings_page');
}

function check_wp_status_settings_page() {
    ?>
<div class="wrap">
    <h1>Check WP status Settings</h1>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <table class="form-table">
            <tr>
                <th scope="row">Token</th>
                <td>
                    <input type="text" name="check_wp_status_token"
                        value="<?php echo esc_attr(get_option('check_wp_status_token')); ?>" />
                    <button type="button" id="generate_token_button">Generate New Token</button>
                </td>
            </tr>
        </table>
        <?php wp_nonce_field('check_wp_status_settings'); ?>
        <input type="hidden" name="action" value="save_check_wp_status_settings" />
        <?php submit_button('Save Settings'); ?>
    </form>
</div>
<script>
(function($) {
    $(document).ready(function() {
        $('#generate_token_button').click(function(e) {
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {
                    action: 'generate_check_wp_status_token'
                },
                success: function(response) {
                    $('input[name="check_wp_status_token"]').val(response.data.token);
                },
                error: function() {
                    alert('An error occurred while generating the token.');
                }
            });
        });
    });
})(jQuery);
</script>
<?php
}

function check_wp_status_settings_save() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    if (!wp_verify_nonce($_POST['_wpnonce'], 'check_wp_status_settings')) {
        wp_die('Invalid nonce specified.');
    }

    if (isset($_POST['check_wp_status_token'])) {
        $token = $_POST['check_wp_status_token'];
        update_option('check_wp_status_token', $token);
    }
    
    wp_safe_redirect(admin_url('options-general.php?page=check-wp-status-settings'));
    exit;
}

function check_wp_status_init() {
    check_wp_status_save_token();
}

add_action('admin_init', 'check_wp_status_init');
add_action('admin_menu', 'check_wp_status_settings_menu');
add_action('admin_post_save_check_wp_status_settings', 'check_wp_status_settings_save');