<?php
function check_wp_status_api_endpoint() {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    require_once( ABSPATH . 'wp-admin/includes/update.php' );

    // Sprawdzenie autoryzacji
    $authorized = false;
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
        $bearer_token = str_replace('Bearer ', '', $auth_header);
        $stored_token = get_option('check_wp_status_token'); // Pobranie tokena zapisanego w panelu administracyjnym wtyczki
        if ($bearer_token === $stored_token) {
            $authorized = true;
        }
    }
    
    if ($authorized) {
        $param = $_GET['data'];

        switch ($param) {
            case "all":
                $response = array(
                    array("name" => "General",
                    "details" => array(
                        'wordpress_version' => get_wordpress_version(),
                        'php_version' => get_php_version(),
                        'is_indexing_enabled' => is_indexing_enabled(),
                        'is_ssl_active' => is_ssl_active(),
                        'environment_type' => get_environment_type(),
                        'admin_url' => "TO DO",
                        'htpasswd' => "TO DO",
                    )),
                    array("name" => "Plugins",
                    "details" => array(
                        'plugins_to_update' => get_plugins_to_update(),
                        'plugins_required_upgrade_php' => get_plugins_to_upgrade_php_count(),
                        'disabled_plugins_count' => get_disabled_plugins_count(),
                        'activated_plugins_count' => get_activated_plugins_count(),
                    )),  
                    array("name" => "Themes",
                    "details" => array(
                        'all_themes' => get_themes_count(),
                        //'themes_details' => get_themes_data(),
                        'themes_require_update' => "TO DO",
                    )),
                    
            
                    
                );
                break;
            default:
                $response = array(
                    'status' => 1,
                );
        }

        header('Content-Type: application/json');
        echo wp_json_encode($response);
        exit;
    } else {
        header('HTTP/1.0 401 Unauthorized');
        exit;
    }
}