<?php

add_filter('plugins_api_args', 'checkwpstatus_client_plugin_update', 10, 2);
add_filter('pre_set_site_transient_update_plugins', 'checkwpstatus_client_plugin_update');

function checkwpstatus_client_plugin_update($args)
{
    $plugin_slug = 'check-wp-status-plugin/check-wp-status.php';
    $current_version = '1.0.0';

    $response = wp_remote_get("https://api.github.com/repos/your-username/your-repo/releases/latest");
    if (!is_wp_error($response)) {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $latest_version = $body['tag_name']; // Najnowsza wersja w Twoim repozytorium

        if (version_compare($current_version, $latest_version, '<')) {
            $args->slug = $plugin_slug;
            $args->version = $latest_version;
            $args->tested = get_bloginfo('version');
            $args->package = $body['zipball_url'];
        }
    }
    return $args;
}