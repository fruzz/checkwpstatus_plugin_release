<?php
function generate_check_wp_status_token() {
    $generated_token = generate_random_token(128);
    wp_send_json_success(array('token' => $generated_token));
}

add_action('wp_ajax_generate_check_wp_status_token', 'generate_check_wp_status_token');