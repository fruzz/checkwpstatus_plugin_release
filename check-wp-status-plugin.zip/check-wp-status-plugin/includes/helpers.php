<?php
function get_wordpress_version() {
    global $wp_version;
    return $wp_version;
}

function get_plugins_to_update() {
    $updates = get_plugin_updates();
    return count($updates);
}

function get_php_version() {
    return phpversion();
}

function is_indexing_enabled() {
    $isIndexingEnabled = get_option('blog_public');
    return $isIndexingEnabled ? 'Tak' : 'Nie';
}

function is_ssl_active() {
    return is_ssl() ? 'Tak' : 'Nie';
}

function get_environment_type() {
    return wp_get_environment_type();
}

function get_activated_plugins_count() {
    $activePlugins = get_option('active_plugins');
    $activated = 0;

    if (is_array($activePlugins)) {
        $activated = count($activePlugins);
        return $activated;
    }
    return 0;
}
function get_disabled_plugins_count() {
    $plugins_directory = WP_CONTENT_DIR . '/plugins';
    $directories = glob($plugins_directory . '/*', GLOB_ONLYDIR);
    $directories_count = count($directories);
    
    return $directories_count - get_activated_plugins_count();
}

function generate_random_token($length = 128) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $characters_length = strlen($characters);
    $random_token = '';

    for ($i = 0; $i < $length; $i++) {
        $random_token .= $characters[rand(0, $characters_length - 1)];
    }

    return $random_token;
}

function get_themes_data() {
    $themes = wp_get_themes();
    $themes_array = array();

    foreach ($themes as $theme) {
        $theme_array = array(
            'name' => $theme->name,
            'version' => $theme->version,
            'author' => $theme->author,
            'author_uri' => $theme->author_uri,
            'template' => $theme->template,
            'stylesheet' => $theme->stylesheet,
            'screenshot' => $theme->screenshot,
            'description' => $theme->description,
            'tags' => $theme->tags,
            'text_domain' => $theme->text_domain,
            'domain_path' => $theme->domain_path,
            'theme_root' => $theme->theme_root,
            'template_dir' => $theme->template_dir,
            'stylesheet_dir' => $theme->stylesheet_dir,
            'template_directory' => $theme->template_directory,
            'stylesheet_directory' => $theme->stylesheet_directory,
            'is_child_theme' => $theme->is_child_theme,
            'errors' => $theme->errors,
        );
        array_push($themes_array, $theme_array);
    }

    return $themes_array;
}

function get_themes_count() {
    return count(get_themes_data());
}


function get_plugins_to_upgrade_php(){

    $plugins = get_plugins();
    $plugins_to_upgrade = array();

    foreach ($plugins as $plugin_path => $plugin) {
        $requires_php = $plugin['RequiresPHP'];
        $current_php_version = phpversion();

        if (version_compare($current_php_version, $requires_php, '<')) {
            array_push($plugins_to_upgrade, $plugin);
        }
    }

    return $plugins_to_upgrade;

}

function get_plugins_to_upgrade_php_count(){
    return count(get_plugins_to_upgrade_php());
}